package co.median.android.widget;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;

import co.median.android.LeanWebView;
import co.median.android.MainActivity;
import co.median.android.WebViewSetup;
import co.median.median_core.AppConfig;
import co.median.median_core.Bridge;
import co.median.median_core.GoNativeWebviewInterface;
import co.median.android.GoNativeApplication;

public class WebViewContainerView extends FrameLayout {

    private ViewGroup webview;
    private boolean isGecko = false;
    private static final String TAG = "MedianCache";

    public WebViewContainerView(@NonNull Context context) {
        super(context);
    }

    public WebViewContainerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initializeWebview(context);
    }

    public WebViewContainerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initializeWebview(context);
    }

    private void initializeWebview(final Context context) {
        AppConfig appConfig = AppConfig.getInstance(context);

        if (appConfig.geckoViewEnabled) {
            try {
                Class<?> classGecko = Class.forName("co.median.plugins.android.geckoview.GNGeckoView");
                Constructor<?> consGecko = classGecko.getConstructor(Context.class);
                webview = (ViewGroup) consGecko.newInstance(context);
                this.isGecko = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            webview = new LeanWebView(context);

            // --- 核心改动：注入手动拦截器 ---
            if (webview instanceof WebView) {
                ((WebView) webview).setWebViewClient(new WebViewClient() {
                    @Nullable
                    @Override
                    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                        String url = request.getUrl().toString();
                        
                        // 拦截逻辑：QQ大图域名、iirose域名、以及常见大图后缀
                        if (url.contains("photo.store.qq.com") || url.contains("scdn.io") || 
                            url.toLowerCase().matches(".*\\.(png|jpg|jpeg|gif|webp).*")) {
                            return handleManualCache(context, url);
                        }
                        return super.shouldInterceptRequest(view, request);
                    }
                });
            }

            try {
                Method getSettingsMethod = webview.getClass().getMethod("getSettings");
                Object settings = getSettingsMethod.invoke(webview);
                if (settings != null) {
                    Class<?> sCls = settings.getClass();
                    sCls.getMethod("setDomStorageEnabled", boolean.class).invoke(settings, true);
                    sCls.getMethod("setDatabaseEnabled", boolean.class).invoke(settings, true);
                    
                    // 强制缓存模式
                    sCls.getMethod("setCacheMode", int.class).invoke(settings, 1); // LOAD_CACHE_ELSE_NETWORK

                    // 禁用 Service Worker (防止它劫持请求导致拦截器失效)
                    try {
                        sCls.getMethod("setServiceWorkersEnabled", boolean.class).invoke(settings, false);
                    } catch (Exception ignored) {}

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            Method setOffscreen = sCls.getMethod("setOffscreenPreRasterAdsEnabled", boolean.class);
                            setOffscreen.invoke(settings, true);
                        } catch (Exception ignored) {}
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        webview.setLayoutParams(layoutParams);
        this.addView(webview);
    }

    /**
     * 手动管理缓存的方法
     */
    private WebResourceResponse handleManualCache(Context context, String urlString) {
        try {
            // 使用你截图里的目录名，确保它不再是空的
            File cacheDir = context.getDir("webview_master_cache", Context.MODE_PRIVATE);
            if (!cacheDir.exists()) cacheDir.mkdirs();

            // 生成唯一文件名（无后缀）
            String fileName = "cache_" + Integer.toHexString(urlString.hashCode());
            File file = new File(cacheDir, fileName);

            // 1. 调用：如果文件存在且不为空，直接返回本地流
            if (file.exists() && file.length() > 0) {
                Log.d(TAG, "检测到本地大图，直接调用: " + fileName);
                return new WebResourceResponse("image/png", "UTF-8", new FileInputStream(file));
            }

            // 2. 保存：如果本地没有，强行下载并写入
            Log.d(TAG, "正在手动抓取大图并存盘: " + urlString);
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(20000);
            conn.connect();

            InputStream is = conn.getInputStream();
            FileOutputStream fos = new FileOutputStream(file);
            byte[] buffer = new byte[1024 * 16];
            int len;
            while ((len = is.read(buffer)) != -1) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            is.close();

            // 返回刚存好的文件流
            return new WebResourceResponse("image/png", "UTF-8", new FileInputStream(file));

        } catch (Exception e) {
            Log.e(TAG, "拦截器下载失败: " + e.getMessage());
            return null;
        }
    }

    public void setupWebview(MainActivity activity, boolean isRoot) {
        if (isGecko) {
            try {
                Class<?> geckoSetupClass = Class.forName("co.median.plugins.android.geckoview.WebViewSetup");
                Method setupWebview = geckoSetupClass.getMethod("setupWebviewForActivity",
                        Activity.class, GoNativeWebviewInterface.class, Bridge.class, boolean.class);
                setupWebview.invoke(geckoSetupClass, activity,
                        (GoNativeWebviewInterface) webview,
                        ((GoNativeApplication) activity.getApplication()).mBridge,
                        isRoot);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            WebViewSetup.setupWebviewForActivity(getWebview(), activity);
        }
    }

    public GoNativeWebviewInterface getWebview() {
        return (GoNativeWebviewInterface) webview;
    }
}
