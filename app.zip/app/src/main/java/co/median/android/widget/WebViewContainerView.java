package co.median.android.widget;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.io.File;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import co.median.android.LeanWebView;
import co.median.android.MainActivity;
import co.median.android.WebViewSetup;
import co.median.median_core.AppConfig;
import co.median.median_core.Bridge;
import co.median.median_core.GoNativeWebviewInterface;
import co.median.android.GoNativeApplication;

public class WebViewContainerView extends FrameLayout {

    private ViewGroup webview;
    private boolean isGecko = false;

    public WebViewContainerView(@NonNull Context context) {
        super(context);
    }

    public WebViewContainerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initializeWebview(context);
    }

    public WebViewContainerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initializeWebview(context);
    }

    private void initializeWebview(Context context) {
        AppConfig appConfig = AppConfig.getInstance(context);

        if (appConfig.geckoViewEnabled) {
            try {
                Class<?> classGecko = Class.forName("co.median.plugins.android.geckoview.GNGeckoView");
                Constructor<?> consGecko = classGecko.getConstructor(Context.class);
                webview = (ViewGroup) consGecko.newInstance(context);
                this.isGecko = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            webview = new LeanWebView(context);

            try {
                Method getSettingsMethod = webview.getClass().getMethod("getSettings");
                Object settings = getSettingsMethod.invoke(webview);
                if (settings != null) {
                    Class<?> sCls = settings.getClass();

                    // ========== 核心缓存增强逻辑 ==========
                    
                    // 1. 强制开启 DOM 存储和数据库存储（很多前端缓存框架依赖这个）
                    sCls.getMethod("setDomStorageEnabled", boolean.class).invoke(settings, true);
                    sCls.getMethod("setDatabaseEnabled", boolean.class).invoke(settings, true);

                    // 2. 指定 App 缓存路径并开启（针对大文件存储稳定性）
                    try {
                        String cacheDir = context.getCacheDir().getAbsolutePath() + File.separator + "webview_cache";
                        File dir = new File(cacheDir);
                        if (!dir.exists()) dir.mkdirs();

                        sCls.getMethod("setAppCacheEnabled", boolean.class).invoke(settings, true);
                        sCls.getMethod("setAppCachePath", String.class).invoke(settings, cacheDir);
                    } catch (Exception ignored) {}

                    // 3. 设置缓存模式：只要本地有就不走网络，极大提升大图二次加载速度
                    sCls.getMethod("setCacheMode", int.class).invoke(settings, -1); // -1 是 LOAD_DEFAULT

                    // 4. 允许文件访问（某些大图加载器需要读取本地临时文件）
                    sCls.getMethod("setAllowFileAccess", boolean.class).invoke(settings, true);

                    // ========== 渲染优化逻辑 (防白屏) ==========
                    
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            Method setOffscreen = sCls.getMethod("setOffscreenPreRasterAdsEnabled", boolean.class);
                            setOffscreen.invoke(settings, true);
                        } catch (Exception ignored) {}
                    }
                    
                    sCls.getMethod("setUseWideViewPort", boolean.class).invoke(settings, true);
                    sCls.getMethod("setLoadWithOverviewMode", boolean.class).invoke(settings, true);
                }

                // 提升渲染进程优先级
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        Method setPriority = webview.getClass().getMethod("setRendererPriorityPolicy", int.class, boolean.class);
                        setPriority.invoke(webview, 2, false); // 2 = IMPORTANT
                    } catch (Exception ignored) {}
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        webview.setLayoutParams(layoutParams);
        this.addView(webview);
    }

    public void setupWebview(MainActivity activity, boolean isRoot) {
        if (isGecko) {
            try {
                Class<?> geckoSetupClass = Class.forName("co.median.plugins.android.geckoview.WebViewSetup");
                Method setupWebview = geckoSetupClass.getMethod("setupWebviewForActivity",
                        Activity.class, GoNativeWebviewInterface.class, Bridge.class, boolean.class);
                setupWebview.invoke(geckoSetupClass, activity,
                        (GoNativeWebviewInterface) webview,
                        ((GoNativeApplication) activity.getApplication()).mBridge,
                        isRoot);
            } catch (ClassNotFoundException | NoSuchMethodException |
                     InvocationTargetException | IllegalAccessException e) {
                e.printStackTrace();
            }
        } else {
            WebViewSetup.setupWebviewForActivity(getWebview(), activity);
        }
    }

    public GoNativeWebviewInterface getWebview() {
        return (GoNativeWebviewInterface) webview;
    }
}
