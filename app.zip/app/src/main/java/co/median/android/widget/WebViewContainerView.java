package co.median.android.widget;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;

import co.median.android.LeanWebView;
import co.median.android.MainActivity;
import co.median.android.WebViewSetup;
import co.median.median_core.AppConfig;
import co.median.median_core.Bridge;
import co.median.median_core.GoNativeWebviewInterface;
import co.median.android.GoNativeApplication;

public class WebViewContainerView extends FrameLayout {

    private ViewGroup webview;
    private boolean isGecko = false;
    private static final String TAG = "MedianBigImageCache";

    public WebViewContainerView(@NonNull Context context) {
        super(context);
        initializeWebview(context);
    }

    public WebViewContainerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initializeWebview(context);
    }

    private void initializeWebview(final Context context) {
        AppConfig appConfig = AppConfig.getInstance(context);

        if (appConfig.geckoViewEnabled) {
            try {
                Class<?> classGecko = Class.forName("co.median.plugins.android.geckoview.GNGeckoView");
                Constructor<?> consGecko = classGecko.getConstructor(Context.class);
                webview = (ViewGroup) consGecko.newInstance(context);
                this.isGecko = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            webview = new LeanWebView(context);
            WebView v = (WebView) webview;

            // --- 核心：手动物理拦截，强行把 12MB 图片存盘 ---
            v.setWebViewClient(new WebViewClient() {
                @Nullable
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    String url = request.getUrl().toString();
                    
                    // 匹配 iirose 大图、QQ空间图片或其他 PNG/JPG
                    if (url.contains("photo.store.qq.com") || url.contains("scdn.io") || 
                        url.toLowerCase().matches(".*\\.(png|jpg|jpeg|gif|webp).*")) {
                        return handleManualCache(context, url);
                    }
                    return super.shouldInterceptRequest(view, request);
                }
            });

            // 反射配置设置
            try {
                Method getSettingsMethod = webview.getClass().getMethod("getSettings");
                Object settings = getSettingsMethod.invoke(webview);
                if (settings != null) {
                    Class<?> sCls = settings.getClass();
                    sCls.getMethod("setDomStorageEnabled", boolean.class).invoke(settings, true);
                    sCls.getMethod("setDatabaseEnabled", boolean.class).invoke(settings, true);
                    sCls.getMethod("setJavaScriptEnabled", boolean.class).invoke(settings, true);
                    
                    // 硬件加速 & 离屏渲染 (解决房间推荐卡顿)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            Method setOffscreen = sCls.getMethod("setOffscreenPreRasterAdsEnabled", boolean.class);
                            setOffscreen.invoke(settings, true);
                        } catch (Exception ignored) {}
                    }

                    // 禁用 Service Worker 防止 JS 劫持请求导致拦截失效
                    try {
                        sCls.getMethod("setServiceWorkersEnabled", boolean.class).invoke(settings, false);
                    } catch (Exception ignored) {}
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 添加到容器，并撑满布局
        this.addView(webview, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /**
     * 核心逻辑：打破 13MB 限制，手动写盘
     */
    private WebResourceResponse handleManualCache(Context context, String urlString) {
        try {
            // 路径：/data/user/0/包名/app_custom_cache/
            File cacheDir = context.getDir("custom_cache", Context.MODE_PRIVATE);
            if (!cacheDir.exists()) cacheDir.mkdirs();

            String fileName = "img_" + Integer.toHexString(urlString.hashCode());
            File file = new File(cacheDir, fileName);

            // 1. 本地有就直接读（不管文件多大）
            if (file.exists() && file.length() > 0) {
                Log.d(TAG, "HIT: 命中本地持久缓存: " + fileName + " (" + file.length() + " bytes)");
                return new WebResourceResponse("image/png", "UTF-8", new FileInputStream(file));
            }

            // 2. 本地没有，暴力下载并存盘
            Log.d(TAG, "MISS: 正在强行存盘大图: " + urlString);
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(20000);
            conn.connect();

            InputStream is = conn.getInputStream();
            FileOutputStream fos = new FileOutputStream(file);
            byte[] buffer = new byte[32768]; // 32KB 缓冲区
            int len;
            while ((len = is.read(buffer)) != -1) {
                fos.write(buffer, 0, len);
            }
            fos.flush();
            fos.close();
            is.close();

            return new WebResourceResponse("image/png", "UTF-8", new FileInputStream(file));

        } catch (Exception e) {
            Log.e(TAG, "Cache Error: " + e.getMessage());
            return null;
        }
    }

    // Median 框架必须的 Setup 方法
    public void setupWebview(MainActivity activity, boolean isRoot) {
        if (isGecko) {
            try {
                Class<?> geckoSetupClass = Class.forName("co.median.plugins.android.geckoview.WebViewSetup");
                Method setupWebviewMethod = geckoSetupClass.getMethod("setupWebviewForActivity",
                        Activity.class, GoNativeWebviewInterface.class, Bridge.class, boolean.class);
                setupWebviewMethod.invoke(null, activity,
                        (GoNativeWebviewInterface) webview,
                        ((GoNativeApplication) activity.getApplication()).mBridge,
                        isRoot);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            WebViewSetup.setupWebviewForActivity((GoNativeWebviewInterface) webview, activity);
        }
    }

    // 常用 Getter
    public ViewGroup getWebview() {
        return webview;
    }

    public boolean isGecko() {
        return isGecko;
    }
}
