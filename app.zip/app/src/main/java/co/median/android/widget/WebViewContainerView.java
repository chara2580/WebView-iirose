package co.median.android.widget;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import co.median.android.LeanWebView;
import co.median.android.MainActivity;
import co.median.android.WebViewSetup;
import co.median.median_core.AppConfig;
import co.median.median_core.Bridge;
import co.median.median_core.GoNativeWebviewInterface;
import co.median.android.GoNativeApplication;

public class WebViewContainerView extends FrameLayout {

    private ViewGroup webview;
    private boolean isGecko = false;
    private static final String TAG = "WebViewCache";

    public WebViewContainerView(@NonNull Context context) {
        super(context);
    }

    public WebViewContainerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initializeWebview(context);
    }

    public WebViewContainerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initializeWebview(context);
    }

    private void initializeWebview(final Context context) {
        AppConfig appConfig = AppConfig.getInstance(context);

        if (appConfig.geckoViewEnabled) {
            try {
                Class<?> classGecko = Class.forName("co.median.plugins.android.geckoview.GNGeckoView");
                Constructor<?> consGecko = classGecko.getConstructor(Context.class);
                webview = (ViewGroup) consGecko.newInstance(context);
                this.isGecko = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            webview = new LeanWebView(context);
            
            // --- 核心修改：注入拦截器 ---
            if (webview instanceof WebView) {
                ((WebView) webview).setWebViewClient(new WebViewClient() {
                    @Nullable
                    @Override
                    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                        String url = request.getUrl().toString();
                        
                        // 关键词过滤：QQ空间图片域名、iirose域名、以及常见图片后缀
                        if (url.contains("photo.store.qq.com") || url.contains("scdn.io") || 
                            url.toLowerCase().matches(".*\\.(png|jpg|jpeg|gif|webp).*")) {
                            return getManualCacheResponse(context, url);
                        }
                        return super.shouldInterceptRequest(view, request);
                    }
                });
            }

            try {
                Method getSettingsMethod = webview.getClass().getMethod("getSettings");
                Object settings = getSettingsMethod.invoke(webview);
                if (settings != null) {
                    Class<?> sCls = settings.getClass();
                    sCls.getMethod("setDomStorageEnabled", boolean.class).invoke(settings, true);
                    sCls.getMethod("setDatabaseEnabled", boolean.class).invoke(settings, true);
                    sCls.getMethod("setCacheMode", int.class).invoke(settings, 1); // LOAD_CACHE_ELSE_NETWORK
                    
                    // 解决白屏问题
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            Method setOffscreen = sCls.getMethod("setOffscreenPreRasterAdsEnabled", boolean.class);
                            setOffscreen.invoke(settings, true);
                        } catch (Exception ignored) {}
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        webview.setLayoutParams(layoutParams);
        this.addView(webview);
    }

    /**
     * 手动拦截与读取逻辑
     */
    private WebResourceResponse getManualCacheResponse(Context context, String urlString) {
        try {
            // 1. 创建私有目录
            File cacheDir = context.getDir("manual_img_bin", Context.MODE_PRIVATE);
            if (!cacheDir.exists()) cacheDir.mkdirs();

            // 2. 使用 URL 的 HashCode 生成唯一文件名
            String fileName = "img_" + Integer.toHexString(urlString.hashCode());
            File cacheFile = new File(cacheDir, fileName);

            // 3. 检查本地是否有缓存（调用）
            if (cacheFile.exists() && cacheFile.length() > 0) {
                Log.d(TAG, "从本地调取大图: " + urlString);
                return new WebResourceResponse(getMimeType(urlString), "UTF-8", new FileInputStream(cacheFile));
            }

            // 4. 本地没有，手动下载（保存）
            Log.d(TAG, "正在强行下载大图存入私有目录: " + urlString);
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(20000);
            conn.connect();

            InputStream is = conn.getInputStream();
            FileOutputStream fos = new FileOutputStream(cacheFile);
            byte[] buffer = new byte[8192];
            int len;
            while ((len = is.read(buffer)) != -1) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            is.close();

            return new WebResourceResponse(getMimeType(urlString), "UTF-8", new FileInputStream(cacheFile));

        } catch (Exception e) {
            Log.e(TAG, "手动缓存失败: " + e.getMessage());
            return null;
        }
    }

    private String getMimeType(String url) {
        if (url.contains(".png")) return "image/png";
        if (url.contains(".jpg") || url.contains(".jpeg")) return "image/jpeg";
        if (url.contains(".webp")) return "image/webp";
        if (url.contains(".gif")) return "image/gif";
        return "image/png"; // 默认针对 QQ 空间大图
    }

    public void setupWebview(MainActivity activity, boolean isRoot) {
        if (isGecko) {
            // ... Gecko 代码保持原样 ...
        } else {
            WebViewSetup.setupWebviewForActivity(getWebview(), activity);
        }
    }

    public GoNativeWebviewInterface getWebview() {
        return (GoNativeWebviewInterface) webview;
    }
}
