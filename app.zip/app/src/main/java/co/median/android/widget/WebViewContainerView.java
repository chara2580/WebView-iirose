package co.median.android.widget;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.io.File;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import co.median.android.LeanWebView;
import co.median.android.MainActivity;
import co.median.android.WebViewSetup;
import co.median.median_core.AppConfig;
import co.median.median_core.Bridge;
import co.median.median_core.GoNativeWebviewInterface;
import co.median.android.GoNativeApplication;

public class WebViewContainerView extends FrameLayout {

    private ViewGroup webview;
    private boolean isGecko = false;

    public WebViewContainerView(@NonNull Context context) {
        super(context);
    }

    public WebViewContainerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initializeWebview(context);
    }

    public WebViewContainerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initializeWebview(context);
    }

    private void initializeWebview(Context context) {
        AppConfig appConfig = AppConfig.getInstance(context);

        if (appConfig.geckoViewEnabled) {
            try {
                Class<?> classGecko = Class.forName("co.median.plugins.android.geckoview.GNGeckoView");
                Constructor<?> consGecko = classGecko.getConstructor(Context.class);
                webview = (ViewGroup) consGecko.newInstance(context);
                this.isGecko = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            webview = new LeanWebView(context);

            try {
                Method getSettingsMethod = webview.getClass().getMethod("getSettings");
                Object settings = getSettingsMethod.invoke(webview);
                if (settings != null) {
                    Class<?> sCls = settings.getClass();

                    // 1. 强制开启存储支持（Chrome 缓存的基础）
                    sCls.getMethod("setDomStorageEnabled", boolean.class).invoke(settings, true);
                    sCls.getMethod("setDatabaseEnabled", boolean.class).invoke(settings, true);

                    // 2. 激进缓存模式：只要本地有，死活不联网 (LOAD_CACHE_ELSE_NETWORK)
                    // 这是对齐 Chrome 体验的关键，解决 12MB 图片反复加载
                    sCls.getMethod("setCacheMode", int.class).invoke(settings, 1); 

                    // 3. 扩大磁盘缓存上限
                    try {
                        // 使用持久化目录，防止被系统作为临时文件清理
                        File cacheDir = context.getDir("webview_master_cache", Context.MODE_PRIVATE);
                        if (!cacheDir.exists()) cacheDir.mkdirs();

                        sCls.getMethod("setAppCacheEnabled", boolean.class).invoke(settings, true);
                        sCls.getMethod("setAppCachePath", String.class).invoke(settings, cacheDir.getAbsolutePath());
                        
                        // 暴力申请 512MB 缓存配额
                        try {
                            Method setMaxSize = sCls.getMethod("setAppCacheMaxSize", long.class);
                            setMaxSize.invoke(settings, 512 * 1024 * 1024L);
                        } catch (Exception ignored) {}
                    } catch (Exception ignored) {}

                    // 4. 解决 12MB PNG 渲染白屏问题
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            Method setOffscreen = sCls.getMethod("setOffscreenPreRasterAdsEnabled", boolean.class);
                            setOffscreen.invoke(settings, true);
                        } catch (Exception ignored) {}
                    }
                    
                    // 提升画质与解码速度
                    sCls.getMethod("setLoadsImagesAutomatically", boolean.class).invoke(settings, true);
                    sCls.getMethod("setUseWideViewPort", boolean.class).invoke(settings, true);
                    sCls.getMethod("setLoadWithOverviewMode", boolean.class).invoke(settings, true);
                }

                // 5. 提升渲染进程优先级 (RENDERER_PRIORITY_IMPORTANT)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        Method setPriority = webview.getClass().getMethod("setRendererPriorityPolicy", int.class, boolean.class);
                        setPriority.invoke(webview, 2, false); 
                    } catch (Exception ignored) {}
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        webview.setLayoutParams(layoutParams);
        this.addView(webview);
    }

    public void setupWebview(MainActivity activity, boolean isRoot) {
        if (isGecko) {
            try {
                Class<?> geckoSetupClass = Class.forName("co.median.plugins.android.geckoview.WebViewSetup");
                Method setupWebview = geckoSetupClass.getMethod("setupWebviewForActivity",
                        Activity.class, GoNativeWebviewInterface.class, Bridge.class, boolean.class);
                setupWebview.invoke(geckoSetupClass, activity,
                        (GoNativeWebviewInterface) webview,
                        ((GoNativeApplication) activity.getApplication()).mBridge,
                        isRoot);
            } catch (ClassNotFoundException | NoSuchMethodException |
                     InvocationTargetException | IllegalAccessException e) {
                e.printStackTrace();
            }
        } else {
            WebViewSetup.setupWebviewForActivity(getWebview(), activity);
        }
    }

    public GoNativeWebviewInterface getWebview() {
        return (GoNativeWebviewInterface) webview;
    }
}
